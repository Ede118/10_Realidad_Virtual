Animated Pixel Planets v1.1 - FREE SAMPLE (6 planets)
=====================================================

This is the free sample of the full pack. Same formats, same quality, 6 of the 58 planets.
Full pack (58 planets) for $6.99: https://reeboolabs.itch.io/pixel-planets-pack

WHAT IS INSIDE
- 6 planets and space bodies (Terran 1, Desert 1, Lava 1, Gas Giant 1, Ringed 1, Star 1).
- Every body is a 60-frame rotation loop. The last frame continues into the first, so it loops seamlessly.
- Every body is rendered separately at 64x64 and at 128x128 pixels (the 128 version is not a scaled copy).
- Spritesheets: 10 columns x 6 rows, row-major, frame 0 at the top left. 64px sheet = 640x384, 128px sheet = 1280x768.
- Transparent background (PNG, RGBA). Hard pixel edges. One shared palette for the whole pack, at most 16 colours per body, light from the upper left on every body.
- A 128px preview GIF per body (gifs/).
- Godot 4 SpriteFrames (.tres) per body and size, animation name "spin", 20 fps, looping.
- manifest.json (names, categories, sizes, frame counts, colour counts).
- Source/palette.gpl and Source/palette.hex: the shared palette (GIMP / Aseprite / Lospec formats).
- Source/frames.json: frame size, frame count, ms per frame, grid order, loop.
- Changelog.txt: version history.
- overview.png (all bodies, one frame each).

FOLDER LAYOUT
pixel_planets/64px/<name>.png       spritesheets 64x64 frames
pixel_planets/128px/<name>.png      spritesheets 128x128 frames
pixel_planets/gifs/<name>.gif       animated preview (128px)
pixel_planets/godot/64/<name>.tres  and  pixel_planets/godot/128/<name>.tres
pixel_planets/Source/               palette.gpl, palette.hex, frames.json

HOW TO USE

Godot 4: copy the folder "pixel_planets" into your project root so it is res://pixel_planets/. Add an AnimatedSprite2D, set Sprite Frames to res://pixel_planets/godot/128/<name>.tres (or 64), and play "spin". The .tres files point to res://pixel_planets/64px and res://pixel_planets/128px, so keep the folder name. Set the texture filter to Nearest (Project Settings > Rendering > Textures > Default Texture Filter) to keep pixels sharp.

Unity: import the PNG, Sprite Mode = Multiple, Filter Mode = Point, Compression = None. Open the Sprite Editor > Slice > Grid By Cell Count, 10 columns x 6 rows (or cell size 64x64 / 128x128). Drag the sliced sprites into the scene to create an animation at 20 fps.

GameMaker: Create Sprite > Import Strip Image. Frames 60, frames per row 10, frame size 64x64 or 128x128. Playback speed 20 fps.

Any engine: slice the sheet in a 10 x 6 grid. Frame i is at column i % 10, row i // 10.

NOTES
- Ringed planets: the ring is part of the sprite, the planet spins inside it.
- Stars have an animated corona that also loops in 60 frames.
- Light comes from the upper left on every body, so they sit well together in one scene.

LICENSE: see LICENSE.txt (royalty-free, commercial use allowed, no resale or redistribution as-is).

Get the full pack: https://reeboolabs.itch.io/pixel-planets-pack

REEBOO Labs - https://reeboolabs.itch.io

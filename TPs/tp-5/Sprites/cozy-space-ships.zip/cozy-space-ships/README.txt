Cozy Space Ships — top-down pixel art ships

8 ships in 3 color schemes (24 ships), each with a 4-frame thrust sheet,
plus lasers, plasma shots, a missile and 3 explosions.

SHIPS (facing up)            size at 1x
  sparrow    fighter         24 x 24
  kestrel    interceptor     24 x 28
  heron      bomber          32 x 30
  wren       scout           20 x 20
  tortoise   freighter       32 x 40
  falcon     corvette        40 x 48
  moth       saucer          26 x 24   (hovers, no thrust sheet)
  gnat       drone           18 x 18   (hovers, no thrust sheet)

Color schemes: cream (teal trim), slate (rose trim), sand (amber trim).

Folders (each in 1x, 2x and 4x):
  ships/        <ship>-<color>.png                 one frame, no flame
                <ship>-<color>-thrust-4f.png       4 frames in a row with the
                                                   engine flame; each frame is
                                                   8 px taller (1x) than the
                                                   ship to fit the flame below
  projectiles/  laser-amber / rose / teal / blue.png        3 x 9
                plasma-teal / rose-4f.png                   4 frames of 10 x 10
                missile-2f.png                              2 frames of 5 x 14
  explosions/   explosion-16 / 32 / 48-8f.png               8 frames each

Suggested speed: thrust 10-12 fps, plasma 8 fps, explosions 12-15 fps.
Light comes from the top left on every sprite. Scale with nearest-neighbor
to keep pixels crisp.

Made to match Cozy Space Backdrops, Cozy Space Station and Walking Crew
(aquumgifts.itch.io). See LICENSE.txt for what you can do with them.
